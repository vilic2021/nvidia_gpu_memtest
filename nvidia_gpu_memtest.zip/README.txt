ENG
NVIDIA GPU Diagnostic Tool 🛠️
A professional tool for comprehensive diagnostics of NVIDIA graphics cards, supporting architectures from Fermi to Pascal.

✨ Features

Full Memory Testing – 16+ verification algorithms with detailed error analysis

Built-in Self-Test (BIST) – Utilizes GPU hardware self-testing capabilities

Real-Time Monitoring – Tracks temperature, power usage, and memory status

ECC Diagnostics – Detects and analyzes memory correction errors

Cross-Architecture Support – Works with Fermi, Kepler, Maxwell, and Pascal GPUs

Detailed Reporting – Full statistics and actionable recommendations

📋 Supported Hardware

GPU Architectures

Fermi (GTX 500 series)

Kepler (GTX 600/700 series)

Maxwell (GTX 900 series)

Pascal (GTX 1000 series)

System Requirements

Linux (Ubuntu 18.04+, Debian 10+, CentOS 7+)

NVIDIA GPU with 1GB+ VRAM

Superuser (root) privileges

GCC 7.0+ and development tools

🚀 Quick Start

Install Dependencies

# Ubuntu/Debian
sudo apt update
sudo apt install build-essential linux-headers-$(uname -r)

# CentOS/RHEL
sudo yum groupinstall "Development Tools"
sudo yum install kernel-devel


Compile the Project

# Optimized build
gcc -o nvidia_diag nvidia_diag.c -O2 -lpthread -lrt -lm

# Check the build
chmod +x nvidia_diag
./nvidia_diag --version


Basic Usage

# Full diagnostic (recommended)
sudo ./nvidia_diag --full

# Save results to file
sudo ./nvidia_diag --full --log diagnostic_report.txt

# Quick memory check
sudo ./nvidia_diag --memory --quick

📊 Operating Modes

Primary Commands

# Comprehensive diagnostics
sudo ./nvidia_diag --full

# Memory test with detailed analysis
sudo ./nvidia_diag --memory --pattern all

# Run built-in GPU tests (BIST)
sudo ./nvidia_diag --bist

# Real-time monitoring
sudo ./nvidia_diag --monitor --interval 2

# Generate report
sudo ./nvidia_diag --report --output report.html


Command-Line Parameters

Parameter	Description	Default
--full	Full diagnostics	✅
--memory	Memory test	
--bist	BIST testing	
--monitor	Monitoring mode	
--quick	Quick mode	
--verbose	Verbose output	
--log <file>	Save log to file	
--interval <sec>	Monitoring interval (in seconds)	5
🔧 Technical Details

Memory Testing Algorithms
The tool uses 16+ patterns for comprehensive memory checking:

Basic patterns: All zeros/ones, Alternating bits

Structural patterns: Incremental, Decremental

Stress patterns: Dead beef, Cafe babe, Complex patterns

Specialized: Walking ones/zeros, Nybble patterns

System Monitoring

GPU Temperature – Overheating control

Power Consumption – Load analysis

ECC Statistics – Memory correction error logs

Clock Frequencies – Core operation monitoring

📈 Result Interpretation

Error Levels

Level	Description	Recommendation
INFO	Informational message	Monitoring
WARNING	Minor issues	Check cooling system
ERROR	Critical errors	Hardware diagnostics
CRITICAL	Hardware failure	Replace components

Sample Report

=== DIAGNOSTIC REPORT ===
GPU: GeForce GTX 1080 (Pascal)
Test duration: 45.2 seconds
Memory tested: 8192 MB

STATISTICS:
- Total tests: 1,500,000
- Memory errors: 12 (0.0008%)
- ECC corrected: 8
- ECC uncorrected: 0
- Max temperature: 78°C

RECOMMENDATIONS:
✅ Memory integrity: Excellent
⚠️  Monitor temperature under load
🔧 Consider cleaning cooling system

⚠️ Important Notices

Safety Information

# Root access is required for hardware testing
# May cause system instability during tests
# Close all applications before running tests

# Always back up important data


Limitations

Linux-only

Requires physical GPU access

Supports up to Pascal architecture only

No multi-GPU support

🐛 Troubleshooting

Common Issues

# Hardware access error
sudo ./nvidia_diag

# GPU not detected
# Check architecture support

# Compilation errors
# Ensure build-essential is installed


Debug Mode

# Verbose output with debug info
sudo ./nvidia_diag --verbose --debug

# Log output to file
sudo ./nvidia_diag --log debug.log --verbose

📝 Usage Examples

Preventive Diagnostics

# Monthly system check
sudo ./nvidia_diag --full --log monthly_check.txt


Problem Diagnosis

# When artifacts appear
sudo ./nvidia_diag --memory --pattern stress

# If overheating occurs
sudo ./nvidia_diag --monitor --interval 1


Production Testing

# Full server-side test
sudo ./nvidia_diag --full --bist --log production_test.txt

🔄 Comparison With Alternatives
Feature	This Tool	MATS
Memory Tests	16+ patterns	3–4 patterns
ECC Monitoring	Real-time	Post-factum
Reporting	Detailed statistics	Error codes
Monitoring	Temp/Power	Not supported
Safety	State preservation	Direct hardware access
📞 Support

Reporting Issues

Run with --verbose --debug

Save output: --log error_report.txt

Include GPU model and driver version

Questions & Suggestions

Check the documentation and existing issues

Use templates for bug reports

Feature suggestions are welcome

📜 License

This project is licensed under the MIT License. Full text available in the LICENSE file.

⚠️ Disclaimer

This tool is intended for diagnostic use only. The authors are not responsible for any hardware damage or data loss. Use at your own risk.

Test on non-critical systems before using in production.

RU
NVIDIA GPU Diagnostic Tool 🛠️
Профессиональный инструмент для комплексной диагностики видеокарт NVIDIA с поддержкой архитектур от Fermi до Pascal.

✨ Возможности
Полное тестирование памяти - 16+ алгоритмов проверки с детальным анализом ошибок

Встроенная самодиагностика (BIST) - Использование аппаратных функций самотестирования GPU

Мониторинг в реальном времени - Контроль температуры, энергопотребления и состояния памяти

ECC диагностика - Обнаружение и анализ ошибок коррекции памяти

Кросс-архитектурная поддержка - Работа с GPU Fermi, Kepler, Maxwell, Pascal

Детальная отчетность - Полная статистика и практические рекомендации

📋 Поддерживаемое оборудование
Архитектуры GPU
Fermi (GTX 500 series)

Kepler (GTX 600/700 series)

Maxwell (GTX 900 series)

Pascal (GTX 1000 series)

Системные требования
Linux (Ubuntu 18.04+, Debian 10+, CentOS 7+)

NVIDIA GPU с 1GB+ видеопамяти

Права суперпользователя

GCC 7.0+ и инструменты разработки

🚀 Быстрый старт
Установка зависимостей
bash
# Ubuntu/Debian
sudo apt update
sudo apt install build-essential linux-headers-$(uname -r)

# CentOS/RHEL
sudo yum groupinstall "Development Tools"
sudo yum install kernel-devel
Компиляция проекта
bash
# Сборка с оптимизацией
gcc -o nvidia_diag nvidia_diag.c -O2 -lpthread -lrt -lm

# Проверка сборки
chmod +x nvidia_diag
./nvidia_diag --version
Базовое использование
bash
# Полная диагностика (рекомендуется)
sudo ./nvidia_diag --full

# Сохранение результатов в файл
sudo ./nvidia_diag --full --log diagnostic_report.txt

# Быстрая проверка памяти
sudo ./nvidia_diag --memory --quick
📊 Режимы работы
Основные команды
bash
# Комплексная диагностика
sudo ./nvidia_diag --full

# Тестирование памяти с детальным анализом
sudo ./nvidia_diag --memory --pattern all

# Запуск встроенных тестов GPU (BIST)
sudo ./nvidia_diag --bist

# Мониторинг в реальном времени
sudo ./nvidia_diag --monitor --interval 2

# Генерация отчета
sudo ./nvidia_diag --report --output report.html
Параметры командной строки
Параметр	Описание	По умолчанию
--full	Полная диагностика	✅
--memory	Тест памяти	
--bist	BIST тестирование	
--monitor	Режим мониторинга	
--quick	Быстрый режим	
--verbose	Подробный вывод	
--log <file>	Сохранение лога	
--interval <sec>	Интервал мониторинга	5
🔧 Технические детали
Алгоритмы тестирования памяти
Инструмент использует 16+ паттернов для всесторонней проверки:

Базовые паттерны: All zeros/ones, Alternating bits

Структурные паттерны: Incremental, Decremental

Стресс-паттерны: Dead beef, Cafe babe, Complex patterns

Специализированные: Walking ones/zeros, Nybble patterns

Мониторинг системы
Температура GPU - Контроль перегрева

Энергопотребление - Анализ нагрузки

ECC статистика - Ошибки коррекции памяти

Тактовые частоты - Мониторинг работы ядер

📈 Интерпретация результатов
Уровни ошибок
Уровень	Описание	Рекомендация
INFO	Информационное сообщение	Мониторинг
WARNING	Незначительные ошибки	Проверить охлаждение
ERROR	Критические ошибки	Диагностика оборудования
CRITICAL	Аппаратные сбои	Замена компонентов
Пример отчета
text
=== DIAGNOSTIC REPORT ===
GPU: GeForce GTX 1080 (Pascal)
Test duration: 45.2 seconds
Memory tested: 8192 MB

STATISTICS:
- Total tests: 1,500,000
- Memory errors: 12 (0.0008%)
- ECC corrected: 8
- ECC uncorrected: 0
- Max temperature: 78°C

RECOMMENDATIONS:
✅ Memory integrity: Excellent
⚠️  Monitor temperature under load
🔧 Consider cleaning cooling system
⚠️ Важные предупреждения
Безопасность использования
bash
# Требуются права root для доступа к оборудованию
# Может вызвать нестабильность системы при тестировании
# Рекомендуется закрыть все приложения перед запуском

# Всегда делайте резервные копии важных данных
Ограничения
Только для Linux систем

Требуется физический доступ к GPU

Поддержка ограничена архитектурами до Pascal

Нет поддержки multi-GPU конфигураций

🐛 Поиск неисправностей
Частые проблемы
bash
# Ошибка доступа к оборудованию
sudo ./nvidia_diag

# GPU не обнаружен
# Проверьте поддержку архитектуры

# Ошибки компиляции
# Убедитесь в установке build-essential
Режим отладки
bash
# Подробный вывод с отладочной информацией
sudo ./nvidia_diag --verbose --debug

# Логирование в файл
sudo ./nvidia_diag --log debug.log --verbose
📝 Примеры использования
Профилактическая диагностика
bash
# Ежемесячная проверка системы
sudo ./nvidia_diag --full --log monthly_check.txt
Диагностика проблем
bash
# При появлении артефактов
sudo ./nvidia_diag --memory --pattern stress

# При перегреве
sudo ./nvidia_diag --monitor --interval 1
Производственное тестирование
bash
# Полный тест для серверных решений
sudo ./nvidia_diag --full --bist --log production_test.txt
🔄 Сравнение с аналогами
Функция	Наш инструмент	MATS
Тесты памяти	16+ паттернов	3-4 паттерна
ECC мониторинг	Real-time	Post-factum
Отчетность	Детальная статистика	Коды ошибок
Мониторинг	Температура/Питание	Отсутствует
Безопасность	Сохранение состояний	Прямой доступ
📞 Поддержка
Сообщение о ошибках
При возникновении проблем:

Запустите с параметрами --verbose --debug

Сохраните вывод в файл: --log error_report.txt

Укажите модель GPU и версию драйвера

Вопросы и предложения
Проверьте документацию и существующие issues

Используйте шаблоны для баг-репортов

Предложения по улучшению приветствуются

📜 Лицензия
Проект распространяется под лицензией MIT. Полный текст лицензии доступен в файле LICENSE.

⚠️ Дисклеймер
Инструмент предназначен для диагностических целей. Авторы не несут ответственности за возможные повреждения оборудования или потерю данных. Используйте на свой риск.

Перед использованием на производственных системах проведите тестирование на непрофильном оборудовании.

